# 🚀 JeetMantra Platform - Quick Start Guide

## What You Got

A complete, production-ready education platform with:

✅ **Frontend** - Modern website (HTML/CSS/JS)  
✅ **Backend** - Supabase database with 15+ tables  
✅ **AI Integration** - MCP server for intelligent features  
✅ **Automation** - n8n workflow for WhatsApp bot  
✅ **Complete Documentation** - Architecture, API, Deployment guides

## 📂 Project Structure

```
jeetmantra-platform/
├── frontend/              # Website files
│   ├── index.html        # Main page
│   ├── css/styles.css    # JeetMantra design system
│   └── js/               # All JavaScript
├── mcp-server/           # AI server
│   ├── index.js          # MCP tools
│   └── package.json      # Dependencies
├── supabase/             # Database
│   └── migrations/       # SQL schema
├── n8n-workflows/        # Automation
│   └── whatsapp-bot.json # WhatsApp AI bot
├── docs/                 # Documentation
│   ├── ARCHITECTURE.md
│   └── DEPLOYMENT.md
└── README.md             # Full guide
```

## ⚡ 5-Minute Local Setup

### 1. Install Dependencies
```bash
cd jeetmantra-platform
npm install
```

### 2. Setup Supabase
1. Go to https://supabase.com
2. Create new project
3. Copy `supabase/migrations/001_initial_schema.sql`
4. Paste in SQL Editor
5. Run it ✅

### 3. Configure Frontend
Edit `frontend/js/supabase-client.js`:
```javascript
const SUPABASE_URL = 'YOUR_URL_HERE';
const SUPABASE_ANON_KEY = 'YOUR_KEY_HERE';
```

### 4. Run Frontend
```bash
npm run dev
# Opens http://localhost:8000
```

### 5. (Optional) Run MCP Server
```bash
# In another terminal
cd mcp-server
npm install
SUPABASE_URL=xxx SUPABASE_SERVICE_KEY=xxx npm start
```

## 🎨 What's Built

### Website Pages
- **Home** - Hero with "Seekho. Bano. Jeeto."
- **About** - Modern Gurukul concept
- **Courses** - Filterable course catalog
- **Earn & Learn** - Referral & earning system
- **Contact** - Lead capture form

### Features
- ✅ User authentication (Email + Phone OTP)
- ✅ Course marketplace
- ✅ Student wallet system
- ✅ Referral tracking
- ✅ Attendance system (QR/OTP)
- ✅ Earning dashboard
- ✅ CRM lead management
- ✅ Real-time notifications
- ✅ WhatsApp AI bot
- ✅ Admin analytics

### Design System
- **Colors**: Saffron Orange (#f97316) + Deep Navy (#0f172a)
- **Typography**: Inter font family
- **Components**: Cards, buttons, modals, forms
- **Responsive**: Mobile-first design

## 🤖 AI Features (MCP)

The MCP server provides 10+ AI tools:

1. `get_student_profile` - Student data
2. `get_student_enrollments` - Course enrollments
3. `get_student_earnings` - Earning breakdown
4. `mark_attendance` - Attendance marking
5. `search_courses` - Smart search
6. `enroll_student` - Auto enrollment
7. `get_referral_stats` - Referral analytics
8. `create_lead` - Lead creation
9. `get_analytics` - Dashboard metrics
10. `send_notification` - Push notifications

**Use with Claude:**
```javascript
// Claude can now manage your entire platform!
const response = await fetch('https://api.anthropic.com/v1/messages', {
  body: JSON.stringify({
    model: 'claude-sonnet-4-20250514',
    messages: [{
      role: 'user',
      content: 'Show me all courses for JEE preparation'
    }],
    mcp_servers: [{
      type: 'url',
      url: 'http://localhost:3001',
      name: 'jeetmantra-mcp'
    }]
  })
});
```

## 📱 n8n Automation

### WhatsApp Bot Workflow
Automatically handles:
- Course inquiries
- Demo bookings
- Lead creation
- AI-powered responses

**Setup:**
1. Import `n8n-workflows/whatsapp-bot.json` into n8n
2. Add Twilio credentials
3. Add Anthropic API key
4. Add Supabase credentials
5. Activate workflow

## 🗄️ Database

### Tables Created (15 total)
- `profiles` - User accounts
- `students` - Student data + wallet
- `teachers` - Teacher profiles
- `partners` - Partner organizations
- `courses` - Course catalog
- `enrollments` - Student enrollments
- `attendance` - Attendance records
- `earnings` - All transactions
- `referrals` - Referral tracking
- `tasks` - Earning tasks
- `bookings` - Class bookings
- `content` - Course materials
- `notifications` - User notifications
- `leads` - CRM leads
- And more...

### Security
- ✅ Row Level Security (RLS) enabled
- ✅ JWT authentication
- ✅ Role-based access control
- ✅ Automatic triggers for wallet updates

## 🚀 Next Steps

### Option 1: Test Locally (5 min)
```bash
npm run dev
# Visit http://localhost:8000
```

### Option 2: Deploy to Production (1 hour)
See `docs/DEPLOYMENT.md` for:
- Netlify/Vercel deployment
- Railway/Fly.io for MCP server
- n8n cloud setup
- WhatsApp bot configuration

### Option 3: Customize (Your time)
- Add your logo to `frontend/assets/images/`
- Customize colors in `frontend/css/styles.css`
- Add more courses via Supabase dashboard
- Extend MCP tools in `mcp-server/index.js`

## 💡 Common Tasks

### Add a New Course
```sql
INSERT INTO courses (title, category, price, description)
VALUES ('JEE Advanced Math', 'academic', 5000, 'Advanced mathematics');
```

### Check Students
```sql
SELECT * FROM students LIMIT 10;
```

### See Earnings
```sql
SELECT student_id, SUM(amount) as total
FROM earnings
GROUP BY student_id;
```

### Test MCP Tool
```bash
npx @modelcontextprotocol/inspector
# Connect to http://localhost:3001
```

## 📖 Full Documentation

- **README.md** - Complete overview
- **docs/ARCHITECTURE.md** - System design
- **docs/DEPLOYMENT.md** - Step-by-step deployment
- **supabase/** - Database schema
- **mcp-server/** - AI integration
- **n8n-workflows/** - Automation

## 🆘 Troubleshooting

**Can't connect to Supabase?**
→ Check URL and API key in `supabase-client.js`

**MCP server won't start?**
→ Check Node version: `node -v` (must be 18+)

**Courses not loading?**
→ Check browser console (F12) for errors

**WhatsApp bot not responding?**
→ Verify n8n webhook URL in Twilio

## 🎯 What This Platform Can Do

✅ Student enrollment automation  
✅ Attendance via QR/OTP  
✅ Referral rewards (₹500 per referral)  
✅ Task-based earning  
✅ WhatsApp AI assistant  
✅ Auto lead management  
✅ Course marketplace  
✅ Teacher portal  
✅ Partner dashboard  
✅ Real-time analytics  

## 💰 Cost Estimate

**Free Tier:**
- Supabase: Free (500MB)
- Netlify: Free
- n8n Cloud: Free (5000 executions/month)
- Railway: $5/month credit

**Production:**
- Supabase Pro: $25/month
- Netlify Pro: $19/month
- n8n Cloud: $20/month
- Railway: ~$10/month
**Total**: ~$75/month

## 🔗 Useful Links

- Supabase Docs: https://supabase.com/docs
- n8n Docs: https://docs.n8n.io
- MCP Protocol: https://modelcontextprotocol.io
- Anthropic API: https://docs.anthropic.com

## 🎉 You're Ready!

You now have a complete, AI-powered education platform.

**Questions?**
Read the docs in `/docs/` or create an issue.

**Happy Building! 🚀**

---

Built with ❤️ for JeetMantra  
Ranchi's Modern Gurukul
