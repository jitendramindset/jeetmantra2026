-- JeetMantra Database Schema
-- Initial Migration

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- ENUM TYPES
-- ============================================

CREATE TYPE user_role AS ENUM ('student', 'teacher', 'partner', 'admin');
CREATE TYPE course_category AS ENUM ('academic', 'skill', 'sport', 'ai', 'language');
CREATE TYPE earning_type AS ENUM ('referral', 'task', 'content', 'bonus');
CREATE TYPE booking_status AS ENUM ('pending', 'confirmed', 'cancelled', 'completed');
CREATE TYPE payment_status AS ENUM ('pending', 'completed', 'failed', 'refunded');

-- ============================================
-- CORE TABLES
-- ============================================

-- Users (extended from Supabase Auth)
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    role user_role NOT NULL DEFAULT 'student',
    full_name TEXT NOT NULL,
    phone VARCHAR(15) NOT NULL UNIQUE,
    whatsapp_number VARCHAR(15),
    email TEXT UNIQUE,
    avatar_url TEXT,
    date_of_birth DATE,
    address JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Students
CREATE TABLE students (
    id UUID PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
    class VARCHAR(20),
    school TEXT,
    parent_name TEXT,
    parent_phone VARCHAR(15),
    wallet_balance DECIMAL(10, 2) DEFAULT 0.00,
    referral_code VARCHAR(10) UNIQUE,
    referred_by UUID REFERENCES students(id),
    total_earnings DECIMAL(10, 2) DEFAULT 0.00,
    total_spent DECIMAL(10, 2) DEFAULT 0.00,
    performance_score INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Teachers
CREATE TABLE teachers (
    id UUID PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
    specialization TEXT[],
    qualification TEXT,
    experience_years INTEGER,
    hourly_rate DECIMAL(8, 2),
    bio TEXT,
    rating DECIMAL(3, 2) DEFAULT 0.00,
    total_students INTEGER DEFAULT 0,
    total_earnings DECIMAL(10, 2) DEFAULT 0.00,
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Partners (Activity Centers, Schools, etc.)
CREATE TABLE partners (
    id UUID PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
    organization_name TEXT NOT NULL,
    organization_type VARCHAR(50),
    services TEXT[],
    commission_rate DECIMAL(5, 2) DEFAULT 10.00,
    total_earnings DECIMAL(10, 2) DEFAULT 0.00,
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Courses
CREATE TABLE courses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    description TEXT,
    category course_category NOT NULL,
    teacher_id UUID REFERENCES teachers(id),
    partner_id UUID REFERENCES partners(id),
    price DECIMAL(8, 2) NOT NULL,
    duration_hours INTEGER,
    max_students INTEGER,
    current_students INTEGER DEFAULT 0,
    thumbnail_url TEXT,
    syllabus JSONB,
    tags TEXT[],
    is_active BOOLEAN DEFAULT TRUE,
    start_date DATE,
    end_date DATE,
    schedule JSONB, -- {day: 'Monday', time: '10:00', duration: 90}
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enrollments
CREATE TABLE enrollments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    enrolled_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    status VARCHAR(20) DEFAULT 'active', -- active, completed, dropped
    payment_status payment_status DEFAULT 'pending',
    amount_paid DECIMAL(8, 2),
    progress_percentage INTEGER DEFAULT 0,
    UNIQUE(student_id, course_id)
);

-- Attendance
CREATE TABLE attendance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'present', -- present, absent, late
    otp_code VARCHAR(6),
    marked_at TIMESTAMP WITH TIME ZONE,
    marked_by UUID REFERENCES profiles(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(student_id, course_id, date)
);

-- Earnings
CREATE TABLE earnings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    amount DECIMAL(10, 2) NOT NULL,
    type earning_type NOT NULL,
    description TEXT,
    reference_id UUID, -- referral_id, task_id, etc.
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Referrals
CREATE TABLE referrals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    referrer_id UUID NOT NULL REFERENCES students(id),
    referred_id UUID NOT NULL REFERENCES students(id),
    referral_code VARCHAR(10) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending', -- pending, completed
    reward_amount DECIMAL(10, 2),
    reward_paid BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

-- Tasks (for earning)
CREATE TABLE tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    description TEXT,
    reward_amount DECIMAL(10, 2) NOT NULL,
    task_type VARCHAR(50), -- content_creation, survey, review
    requirements JSONB,
    is_active BOOLEAN DEFAULT TRUE,
    max_completions INTEGER,
    current_completions INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Task Completions
CREATE TABLE task_completions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    task_id UUID NOT NULL REFERENCES tasks(id),
    student_id UUID NOT NULL REFERENCES students(id),
    submission JSONB,
    status VARCHAR(20) DEFAULT 'pending', -- pending, approved, rejected
    reviewed_by UUID REFERENCES profiles(id),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(task_id, student_id)
);

-- Bookings
CREATE TABLE bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID NOT NULL REFERENCES students(id),
    course_id UUID REFERENCES courses(id),
    partner_id UUID REFERENCES partners(id),
    booking_type VARCHAR(50), -- demo, regular, activity
    scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL,
    duration_minutes INTEGER,
    status booking_status DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Content Library
CREATE TABLE content (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    course_id UUID REFERENCES courses(id),
    teacher_id UUID REFERENCES teachers(id),
    title TEXT NOT NULL,
    description TEXT,
    content_type VARCHAR(50), -- video, pdf, notes, quiz
    file_url TEXT,
    thumbnail_url TEXT,
    duration_minutes INTEGER,
    is_free BOOLEAN DEFAULT FALSE,
    views INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Notifications
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50), -- attendance, payment, earning, course
    is_read BOOLEAN DEFAULT FALSE,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Leads (CRM)
CREATE TABLE leads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    full_name TEXT NOT NULL,
    phone VARCHAR(15) NOT NULL,
    email TEXT,
    source VARCHAR(50), -- website, whatsapp, referral, partner
    interest TEXT[],
    class VARCHAR(20),
    status VARCHAR(20) DEFAULT 'new', -- new, contacted, qualified, converted, lost
    assigned_to UUID REFERENCES profiles(id),
    notes TEXT,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- INDEXES
-- ============================================

CREATE INDEX idx_students_referral_code ON students(referral_code);
CREATE INDEX idx_students_wallet ON students(wallet_balance);
CREATE INDEX idx_courses_category ON courses(category);
CREATE INDEX idx_courses_teacher ON courses(teacher_id);
CREATE INDEX idx_enrollments_student ON enrollments(student_id);
CREATE INDEX idx_enrollments_course ON enrollments(course_id);
CREATE INDEX idx_attendance_date ON attendance(date);
CREATE INDEX idx_earnings_student ON earnings(student_id);
CREATE INDEX idx_earnings_type ON earnings(type);
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_content_course ON content(course_id);

-- ============================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE earnings ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE content ENABLE ROW LEVEL SECURITY;

-- Profiles: Users can read their own profile
CREATE POLICY "Users can read own profile" ON profiles
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
    FOR UPDATE USING (auth.uid() = id);

-- Students: Can read own data
CREATE POLICY "Students can read own data" ON students
    FOR SELECT USING (auth.uid() = id);

-- Courses: Public read access
CREATE POLICY "Anyone can view active courses" ON courses
    FOR SELECT USING (is_active = TRUE);

-- Enrollments: Students can see their enrollments
CREATE POLICY "Students can view own enrollments" ON enrollments
    FOR SELECT USING (auth.uid() = student_id);

-- Earnings: Students can see their earnings
CREATE POLICY "Students can view own earnings" ON earnings
    FOR SELECT USING (auth.uid() = student_id);

-- Notifications: Users can see their notifications
CREATE POLICY "Users can view own notifications" ON notifications
    FOR SELECT USING (auth.uid() = user_id);

-- Content: Enrolled students can view content
CREATE POLICY "Enrolled students can view content" ON content
    FOR SELECT USING (
        is_free = TRUE OR
        EXISTS (
            SELECT 1 FROM enrollments
            WHERE enrollments.student_id = auth.uid()
            AND enrollments.course_id = content.course_id
            AND enrollments.status = 'active'
        )
    );

-- ============================================
-- FUNCTIONS
-- ============================================

-- Function to generate unique referral code
CREATE OR REPLACE FUNCTION generate_referral_code()
RETURNS TRIGGER AS $$
BEGIN
    NEW.referral_code := 'JM' || UPPER(SUBSTRING(MD5(RANDOM()::TEXT) FROM 1 FOR 6));
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_referral_code
    BEFORE INSERT ON students
    FOR EACH ROW
    WHEN (NEW.referral_code IS NULL)
    EXECUTE FUNCTION generate_referral_code();

-- Function to update wallet balance
CREATE OR REPLACE FUNCTION update_wallet_on_earning()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE students
    SET wallet_balance = wallet_balance + NEW.amount,
        total_earnings = total_earnings + NEW.amount
    WHERE id = NEW.student_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_wallet_trigger
    AFTER INSERT ON earnings
    FOR EACH ROW
    EXECUTE FUNCTION update_wallet_on_earning();

-- Function to update course student count
CREATE OR REPLACE FUNCTION update_course_students()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE courses
        SET current_students = current_students + 1
        WHERE id = NEW.course_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE courses
        SET current_students = current_students - 1
        WHERE id = OLD.course_id;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_students_count
    AFTER INSERT OR DELETE ON enrollments
    FOR EACH ROW
    EXECUTE FUNCTION update_course_students();

-- Update timestamp function
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_profiles_timestamp
    BEFORE UPDATE ON profiles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_courses_timestamp
    BEFORE UPDATE ON courses
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_leads_timestamp
    BEFORE UPDATE ON leads
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();
