// Authentication API

const AuthAPI = {
    // Sign up with email and password
    async signUp(email, password, userData) {
        try {
            const { data, error } = await supabaseClient.auth.signUp({
                email: email,
                password: password,
                options: {
                    data: userData
                }
            });

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Sign up error:', error);
            return { success: false, error: error.message };
        }
    },

    // Sign in with email and password
    async signIn(email, password) {
        try {
            const { data, error } = await supabaseClient.auth.signInWithPassword({
                email: email,
                password: password
            });

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Sign in error:', error);
            return { success: false, error: error.message };
        }
    },

    // Sign in with phone (OTP)
    async signInWithPhone(phone) {
        try {
            const { data, error } = await supabaseClient.auth.signInWithOtp({
                phone: phone
            });

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Phone sign in error:', error);
            return { success: false, error: error.message };
        }
    },

    // Verify OTP
    async verifyOTP(phone, token) {
        try {
            const { data, error } = await supabaseClient.auth.verifyOtp({
                phone: phone,
                token: token,
                type: 'sms'
            });

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('OTP verification error:', error);
            return { success: false, error: error.message };
        }
    },

    // Sign out
    async signOut() {
        try {
            const { error } = await supabaseClient.auth.signOut();
            if (error) throw error;
            
            return { success: true };
        } catch (error) {
            console.error('Sign out error:', error);
            return { success: false, error: error.message };
        }
    },

    // Reset password
    async resetPassword(email) {
        try {
            const { data, error } = await supabaseClient.auth.resetPasswordForEmail(email);
            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Password reset error:', error);
            return { success: false, error: error.message };
        }
    },

    // Update user profile
    async updateProfile(userId, profileData) {
        try {
            const { data, error } = await supabaseClient
                .from('profiles')
                .update(profileData)
                .eq('id', userId)
                .select();

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Profile update error:', error);
            return { success: false, error: error.message };
        }
    },

    // Create student profile
    async createStudentProfile(userId, studentData) {
        try {
            // First update profile
            await this.updateProfile(userId, {
                role: 'student',
                ...studentData.profile
            });

            // Then create student entry
            const { data, error } = await supabaseClient
                .from('students')
                .insert({
                    id: userId,
                    ...studentData.student
                })
                .select();

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Student profile creation error:', error);
            return { success: false, error: error.message };
        }
    },

    // Create teacher profile
    async createTeacherProfile(userId, teacherData) {
        try {
            await this.updateProfile(userId, {
                role: 'teacher',
                ...teacherData.profile
            });

            const { data, error } = await supabaseClient
                .from('teachers')
                .insert({
                    id: userId,
                    ...teacherData.teacher
                })
                .select();

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Teacher profile creation error:', error);
            return { success: false, error: error.message };
        }
    }
};

window.AuthAPI = AuthAPI;
