// Courses API

const CoursesAPI = {
    // Fetch all courses
    async getAllCourses() {
        try {
            const { data, error } = await supabaseClient
                .from('courses')
                .select(`
                    *,
                    teacher:teachers(id, specialization, rating),
                    partner:partners(id, organization_name)
                `)
                .eq('is_active', true)
                .order('created_at', { ascending: false });

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error fetching courses:', error);
            return { success: false, error: error.message };
        }
    },

    // Fetch courses by category
    async getCoursesByCategory(category) {
        try {
            const { data, error } = await supabaseClient
                .from('courses')
                .select('*')
                .eq('category', category)
                .eq('is_active', true);

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error fetching courses by category:', error);
            return { success: false, error: error.message };
        }
    },

    // Search courses
    async searchCourses(searchTerm) {
        try {
            const { data, error } = await supabaseClient
                .from('courses')
                .select('*')
                .or(`title.ilike.%${searchTerm}%,description.ilike.%${searchTerm}%`)
                .eq('is_active', true);

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error searching courses:', error);
            return { success: false, error: error.message };
        }
    },

    // Get single course details
    async getCourse(courseId) {
        try {
            const { data, error } = await supabaseClient
                .from('courses')
                .select(`
                    *,
                    teacher:teachers(*),
                    partner:partners(*),
                    content:content(*)
                `)
                .eq('id', courseId)
                .single();

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error fetching course:', error);
            return { success: false, error: error.message };
        }
    },

    // Enroll in a course
    async enrollCourse(studentId, courseId, paymentData) {
        try {
            const { data, error } = await supabaseClient
                .from('enrollments')
                .insert({
                    student_id: studentId,
                    course_id: courseId,
                    amount_paid: paymentData.amount,
                    payment_status: paymentData.status || 'pending'
                })
                .select();

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error enrolling in course:', error);
            return { success: false, error: error.message };
        }
    },

    // Get student enrollments
    async getStudentEnrollments(studentId) {
        try {
            const { data, error } = await supabaseClient
                .from('enrollments')
                .select(`
                    *,
                    course:courses(*)
                `)
                .eq('student_id', studentId)
                .order('enrolled_at', { ascending: false });

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error fetching enrollments:', error);
            return { success: false, error: error.message };
        }
    },

    // Book a demo
    async bookDemo(bookingData) {
        try {
            const { data, error } = await supabaseClient
                .from('bookings')
                .insert({
                    ...bookingData,
                    booking_type: 'demo',
                    status: 'pending'
                })
                .select();

            if (error) throw error;
            
            // Also create a lead
            await supabaseClient
                .from('leads')
                .insert({
                    full_name: bookingData.full_name,
                    phone: bookingData.phone,
                    email: bookingData.email,
                    source: 'website',
                    interest: bookingData.interest || [],
                    status: 'new'
                });

            return { success: true, data };
        } catch (error) {
            console.error('Error booking demo:', error);
            return { success: false, error: error.message };
        }
    },

    // Get course content
    async getCourseContent(courseId) {
        try {
            const { data, error } = await supabaseClient
                .from('content')
                .select('*')
                .eq('course_id', courseId)
                .order('created_at', { ascending: false });

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error fetching course content:', error);
            return { success: false, error: error.message };
        }
    }
};

window.CoursesAPI = CoursesAPI;
