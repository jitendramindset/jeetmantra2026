// Earnings API

const EarningsAPI = {
    // Get student earnings
    async getStudentEarnings(studentId) {
        try {
            const { data, error } = await supabaseClient
                .from('earnings')
                .select('*')
                .eq('student_id', studentId)
                .order('created_at', { ascending: false });

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error fetching earnings:', error);
            return { success: false, error: error.message };
        }
    },

    // Get wallet balance
    async getWalletBalance(studentId) {
        try {
            const { data, error } = await supabaseClient
                .from('students')
                .select('wallet_balance, total_earnings, total_spent')
                .eq('id', studentId)
                .single();

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error fetching wallet balance:', error);
            return { success: false, error: error.message };
        }
    },

    // Create referral
    async createReferral(referrerId, referralCode, referredData) {
        try {
            // Check if referral code is valid
            const { data: referrer, error: refError } = await supabaseClient
                .from('students')
                .select('id')
                .eq('referral_code', referralCode)
                .single();

            if (refError || !referrer) {
                throw new Error('Invalid referral code');
            }

            // Create the referred user (this would be part of sign-up process)
            // For now, just record the referral
            const { data, error } = await supabaseClient
                .from('referrals')
                .insert({
                    referrer_id: referrer.id,
                    referral_code: referralCode,
                    ...referredData
                })
                .select();

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error creating referral:', error);
            return { success: false, error: error.message };
        }
    },

    // Complete referral (when referred person makes first payment)
    async completeReferral(referralId, rewardAmount = 500) {
        try {
            // Update referral status
            const { data: referral, error: refError } = await supabaseClient
                .from('referrals')
                .update({
                    status: 'completed',
                    completed_at: new Date().toISOString(),
                    reward_amount: rewardAmount,
                    reward_paid: true
                })
                .eq('id', referralId)
                .select()
                .single();

            if (refError) throw refError;

            // Add earning to referrer
            const { data, error } = await supabaseClient
                .from('earnings')
                .insert({
                    student_id: referral.referrer_id,
                    amount: rewardAmount,
                    type: 'referral',
                    description: 'Referral reward',
                    reference_id: referralId
                })
                .select();

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error completing referral:', error);
            return { success: false, error: error.message };
        }
    },

    // Get available tasks
    async getAvailableTasks() {
        try {
            const { data, error } = await supabaseClient
                .from('tasks')
                .select('*')
                .eq('is_active', true)
                .lt('current_completions', 'max_completions');

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error fetching tasks:', error);
            return { success: false, error: error.message };
        }
    },

    // Submit task completion
    async submitTask(taskId, studentId, submission) {
        try {
            const { data, error } = await supabaseClient
                .from('task_completions')
                .insert({
                    task_id: taskId,
                    student_id: studentId,
                    submission: submission,
                    status: 'pending'
                })
                .select();

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error submitting task:', error);
            return { success: false, error: error.message };
        }
    },

    // Get task completions
    async getTaskCompletions(studentId) {
        try {
            const { data, error } = await supabaseClient
                .from('task_completions')
                .select(`
                    *,
                    task:tasks(*)
                `)
                .eq('student_id', studentId)
                .order('created_at', { ascending: false });

            if (error) throw error;
            
            return { success: true, data };
        } catch (error) {
            console.error('Error fetching task completions:', error);
            return { success: false, error: error.message };
        }
    },

    // Spend wallet balance (e.g., for course enrollment)
    async spendWalletBalance(studentId, amount, description, referenceId) {
        try {
            // Record negative earning (expense)
            const { data, error } = await supabaseClient
                .from('earnings')
                .insert({
                    student_id: studentId,
                    amount: -Math.abs(amount),
                    type: 'bonus', // or create a 'spending' type
                    description: description,
                    reference_id: referenceId
                })
                .select();

            if (error) throw error;

            // Update wallet balance is handled by trigger
            
            return { success: true, data };
        } catch (error) {
            console.error('Error spending wallet balance:', error);
            return { success: false, error: error.message };
        }
    }
};

window.EarningsAPI = EarningsAPI;
