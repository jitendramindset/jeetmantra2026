// Main Application Logic

document.addEventListener('DOMContentLoaded', async () => {
    console.log('🚀 JeetMantra Platform Initialized');

    // Initialize components
    initializeHeader();
    initializeCourseFilters();
    await loadCourses();
    initializeModals();
    initializeForms();
    checkAuthState();

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
});

// Header functionality
function initializeHeader() {
    const header = document.getElementById('header');
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');

    // Sticky header on scroll
    window.addEventListener('scroll', () => {
        if (window.scrollY > 100) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // Mobile menu toggle
    navToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        navToggle.classList.toggle('active');
    });

    // Close mobile menu when clicking a link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            navToggle.classList.remove('active');
        });
    });
}

// Course filters
function initializeCourseFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            button.classList.add('active');
            
            const category = button.dataset.category;
            filterCourses(category);
        });
    });
}

// Load and display courses
async function loadCourses() {
    const courseGrid = document.getElementById('courseGrid');
    courseGrid.innerHTML = '<div class="loading">Loading courses...</div>';

    try {
        const result = await CoursesAPI.getAllCourses();
        
        if (result.success && result.data) {
            displayCourses(result.data);
        } else {
            courseGrid.innerHTML = '<div class="error">Failed to load courses. Please try again.</div>';
        }
    } catch (error) {
        console.error('Error loading courses:', error);
        courseGrid.innerHTML = '<div class="error">Failed to load courses. Please try again.</div>';
    }
}

// Display courses in grid
function displayCourses(courses) {
    const courseGrid = document.getElementById('courseGrid');
    
    if (courses.length === 0) {
        courseGrid.innerHTML = '<div class="no-results">No courses found.</div>';
        return;
    }

    courseGrid.innerHTML = courses.map(course => createCourseCard(course)).join('');

    // Add click handlers to course cards
    document.querySelectorAll('.course-card').forEach(card => {
        card.addEventListener('click', (e) => {
            if (!e.target.classList.contains('btn')) {
                const courseId = card.dataset.courseId;
                window.location.href = `/course/${courseId}`;
            }
        });
    });
}

// Create course card HTML
function createCourseCard(course) {
    return `
        <div class="course-card" data-course-id="${course.id}" data-category="${course.category}">
            <img src="${course.thumbnail_url || '/assets/images/course-placeholder.jpg'}" alt="${course.title}" class="course-image">
            <div class="course-content">
                <span class="course-category">${course.category}</span>
                <h3 class="course-title">${course.title}</h3>
                <p class="course-description">${course.description || 'Learn more about this course'}</p>
                <div class="course-footer">
                    <span class="course-price">₹${course.price.toLocaleString()}</span>
                    <button class="btn btn-primary btn-sm" onclick="handleEnrollClick('${course.id}', event)">Enroll Now</button>
                </div>
            </div>
        </div>
    `;
}

// Filter courses by category
function filterCourses(category) {
    const courseCards = document.querySelectorAll('.course-card');
    
    courseCards.forEach(card => {
        if (category === 'all' || card.dataset.category === category) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// Handle enroll button click
window.handleEnrollClick = async (courseId, event) => {
    event.stopPropagation();
    
    // Check if user is logged in
    const isAuth = await SupabaseHelper.isAuthenticated();
    
    if (!isAuth) {
        openAuthModal();
        return;
    }

    // Redirect to course enrollment page
    window.location.href = `/enroll/${courseId}`;
};

// Initialize modals
function initializeModals() {
    // Auth modal
    const authModal = document.getElementById('authModal');
    const demoModal = document.getElementById('demoModal');
    
    // Login button
    document.getElementById('loginBtn').addEventListener('click', () => {
        openAuthModal();
    });

    // Demo buttons
    document.querySelectorAll('[id*="demoBtn"], [id*="Demo"]').forEach(btn => {
        btn.addEventListener('click', () => {
            openDemoModal();
        });
    });

    // Close modals
    document.querySelectorAll('.modal-close').forEach(closeBtn => {
        closeBtn.addEventListener('click', () => {
            closeBtn.closest('.modal').classList.remove('active');
        });
    });

    // Close on outside click
    [authModal, demoModal].forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });
}

// Open authentication modal
function openAuthModal() {
    const authModal = document.getElementById('authModal');
    const authContainer = document.getElementById('authContainer');
    
    authContainer.innerHTML = `
        <h2>Welcome to JeetMantra</h2>
        <div class="auth-tabs">
            <button class="auth-tab active" data-tab="login">Login</button>
            <button class="auth-tab" data-tab="signup">Sign Up</button>
        </div>
        <div id="loginForm" class="auth-form">
            <input type="email" id="loginEmail" placeholder="Email" required>
            <input type="password" id="loginPassword" placeholder="Password" required>
            <button class="btn btn-primary btn-block" onclick="handleLogin()">Login</button>
            <div class="divider">OR</div>
            <button class="btn btn-outline btn-block" onclick="handlePhoneLogin()">Login with Phone</button>
        </div>
        <div id="signupForm" class="auth-form" style="display: none;">
            <input type="text" id="signupName" placeholder="Full Name" required>
            <input type="email" id="signupEmail" placeholder="Email" required>
            <input type="tel" id="signupPhone" placeholder="Phone Number" required>
            <input type="password" id="signupPassword" placeholder="Password" required>
            <select id="signupRole" required>
                <option value="">I am a...</option>
                <option value="student">Student</option>
                <option value="teacher">Teacher</option>
                <option value="partner">Partner</option>
            </select>
            <button class="btn btn-primary btn-block" onclick="handleSignup()">Sign Up</button>
        </div>
    `;
    
    authModal.classList.add('active');

    // Tab switching
    document.querySelectorAll('.auth-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            const tabName = tab.dataset.tab;
            document.getElementById('loginForm').style.display = tabName === 'login' ? 'flex' : 'none';
            document.getElementById('signupForm').style.display = tabName === 'signup' ? 'flex' : 'none';
        });
    });
}

// Open demo booking modal
function openDemoModal() {
    const demoModal = document.getElementById('demoModal');
    demoModal.classList.add('active');
}

// Handle login
window.handleLogin = async () => {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    if (!email || !password) {
        alert('Please enter email and password');
        return;
    }

    const result = await AuthAPI.signIn(email, password);
    
    if (result.success) {
        alert('Login successful!');
        document.getElementById('authModal').classList.remove('active');
        window.location.reload();
    } else {
        alert('Login failed: ' + result.error);
    }
};

// Handle signup
window.handleSignup = async () => {
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const phone = document.getElementById('signupPhone').value;
    const password = document.getElementById('signupPassword').value;
    const role = document.getElementById('signupRole').value;

    if (!name || !email || !phone || !password || !role) {
        alert('Please fill in all fields');
        return;
    }

    const result = await AuthAPI.signUp(email, password, {
        full_name: name,
        phone: phone,
        role: role
    });
    
    if (result.success) {
        alert('Signup successful! Please check your email for verification.');
        document.getElementById('authModal').classList.remove('active');
    } else {
        alert('Signup failed: ' + result.error);
    }
};

// Initialize forms
function initializeForms() {
    const contactForm = document.getElementById('contactForm');
    
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(contactForm);
        const data = Object.fromEntries(formData);
        
        // Create lead
        const result = await CoursesAPI.bookDemo({
            full_name: data.name,
            phone: data.phone,
            email: data.email,
            interest: [data.interest]
        });

        if (result.success) {
            alert('Thank you! We will contact you soon.');
            contactForm.reset();
        } else {
            alert('Something went wrong. Please try again.');
        }
    });
}

// Check authentication state
async function checkAuthState() {
    const user = await SupabaseHelper.getCurrentUser();
    
    if (user) {
        // Update UI for logged-in user
        document.getElementById('loginBtn').textContent = 'Dashboard';
        document.getElementById('loginBtn').addEventListener('click', () => {
            window.location.href = '/dashboard';
        });
    }

    // Listen for auth changes
    SupabaseHelper.onAuthStateChange((event, session) => {
        if (event === 'SIGNED_IN') {
            console.log('User signed in');
        } else if (event === 'SIGNED_OUT') {
            console.log('User signed out');
            window.location.reload();
        }
    });
}

// Export functions for global use
window.JeetMantraApp = {
    loadCourses,
    filterCourses,
    openAuthModal,
    openDemoModal
};
