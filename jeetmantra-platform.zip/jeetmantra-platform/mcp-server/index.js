#!/usr/bin/env node

/**
 * JeetMantra MCP Server
 * Provides AI tools for student management, course operations, and analytics
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { createClient } from '@supabase/supabase-js';
import { z } from 'zod';
import dotenv from 'dotenv';

dotenv.config();

// Initialize Supabase client
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// Create MCP server
const server = new Server(
  {
    name: 'jeetmantra-mcp-server',
    version: '1.0.0',
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// ============================================
// STUDENT MANAGEMENT TOOLS
// ============================================

// Get student profile
server.setRequestHandler('tools/list', async () => {
  return {
    tools: [
      {
        name: 'get_student_profile',
        description: 'Retrieve complete student profile including wallet, enrollments, and performance',
        inputSchema: {
          type: 'object',
          properties: {
            student_id: {
              type: 'string',
              description: 'UUID of the student',
            },
          },
          required: ['student_id'],
        },
      },
      {
        name: 'get_student_enrollments',
        description: 'Get all courses a student is enrolled in with progress tracking',
        inputSchema: {
          type: 'object',
          properties: {
            student_id: {
              type: 'string',
              description: 'UUID of the student',
            },
          },
          required: ['student_id'],
        },
      },
      {
        name: 'get_student_earnings',
        description: 'Get detailed earnings breakdown including referrals, tasks, and bonuses',
        inputSchema: {
          type: 'object',
          properties: {
            student_id: {
              type: 'string',
              description: 'UUID of the student',
            },
            type: {
              type: 'string',
              description: 'Filter by earning type: referral, task, content, bonus',
              enum: ['referral', 'task', 'content', 'bonus'],
            },
          },
          required: ['student_id'],
        },
      },
      {
        name: 'mark_attendance',
        description: 'Mark student attendance for a class session',
        inputSchema: {
          type: 'object',
          properties: {
            student_id: {
              type: 'string',
              description: 'UUID of the student',
            },
            course_id: {
              type: 'string',
              description: 'UUID of the course',
            },
            status: {
              type: 'string',
              description: 'Attendance status',
              enum: ['present', 'absent', 'late'],
            },
            date: {
              type: 'string',
              description: 'Date in YYYY-MM-DD format',
            },
          },
          required: ['student_id', 'course_id', 'status', 'date'],
        },
      },
      {
        name: 'search_courses',
        description: 'Search and filter available courses by category, price, teacher, etc.',
        inputSchema: {
          type: 'object',
          properties: {
            query: {
              type: 'string',
              description: 'Search query for course title or description',
            },
            category: {
              type: 'string',
              description: 'Course category',
              enum: ['academic', 'skill', 'sport', 'ai', 'language'],
            },
            max_price: {
              type: 'number',
              description: 'Maximum price filter',
            },
          },
        },
      },
      {
        name: 'enroll_student',
        description: 'Enroll a student in a course with payment processing',
        inputSchema: {
          type: 'object',
          properties: {
            student_id: {
              type: 'string',
              description: 'UUID of the student',
            },
            course_id: {
              type: 'string',
              description: 'UUID of the course',
            },
            amount: {
              type: 'number',
              description: 'Payment amount',
            },
            use_wallet: {
              type: 'boolean',
              description: 'Use wallet balance for payment',
              default: false,
            },
          },
          required: ['student_id', 'course_id', 'amount'],
        },
      },
      {
        name: 'get_referral_stats',
        description: 'Get referral statistics and earnings for a student',
        inputSchema: {
          type: 'object',
          properties: {
            student_id: {
              type: 'string',
              description: 'UUID of the student',
            },
          },
          required: ['student_id'],
        },
      },
      {
        name: 'create_lead',
        description: 'Create a new lead from website inquiry or WhatsApp chat',
        inputSchema: {
          type: 'object',
          properties: {
            full_name: {
              type: 'string',
              description: 'Full name of the lead',
            },
            phone: {
              type: 'string',
              description: 'Phone number',
            },
            email: {
              type: 'string',
              description: 'Email address',
            },
            source: {
              type: 'string',
              description: 'Lead source',
              enum: ['website', 'whatsapp', 'referral', 'partner'],
            },
            interest: {
              type: 'array',
              items: { type: 'string' },
              description: 'Areas of interest',
            },
          },
          required: ['full_name', 'phone', 'source'],
        },
      },
      {
        name: 'get_analytics',
        description: 'Get comprehensive analytics for admin dashboard',
        inputSchema: {
          type: 'object',
          properties: {
            metric: {
              type: 'string',
              description: 'Analytics metric to retrieve',
              enum: ['enrollments', 'revenue', 'students', 'courses', 'earnings_paid'],
            },
            start_date: {
              type: 'string',
              description: 'Start date in YYYY-MM-DD format',
            },
            end_date: {
              type: 'string',
              description: 'End date in YYYY-MM-DD format',
            },
          },
          required: ['metric'],
        },
      },
      {
        name: 'send_notification',
        description: 'Send notification to a user via database (triggers external notification systems)',
        inputSchema: {
          type: 'object',
          properties: {
            user_id: {
              type: 'string',
              description: 'UUID of the user',
            },
            title: {
              type: 'string',
              description: 'Notification title',
            },
            message: {
              type: 'string',
              description: 'Notification message',
            },
            type: {
              type: 'string',
              description: 'Notification type',
              enum: ['attendance', 'payment', 'earning', 'course', 'general'],
            },
          },
          required: ['user_id', 'title', 'message', 'type'],
        },
      },
    ],
  };
});

// Handle tool execution
server.setRequestHandler('tools/call', async (request) => {
  const { name, arguments: args } = request.params;

  try {
    switch (name) {
      case 'get_student_profile': {
        const { data, error } = await supabase
          .from('students')
          .select(`
            *,
            profile:profiles(*)
          `)
          .eq('id', args.student_id)
          .single();

        if (error) throw error;

        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(data, null, 2),
            },
          ],
        };
      }

      case 'get_student_enrollments': {
        const { data, error } = await supabase
          .from('enrollments')
          .select(`
            *,
            course:courses(*)
          `)
          .eq('student_id', args.student_id);

        if (error) throw error;

        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(data, null, 2),
            },
          ],
        };
      }

      case 'get_student_earnings': {
        let query = supabase
          .from('earnings')
          .select('*')
          .eq('student_id', args.student_id);

        if (args.type) {
          query = query.eq('type', args.type);
        }

        const { data, error } = await query.order('created_at', { ascending: false });

        if (error) throw error;

        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(data, null, 2),
            },
          ],
        };
      }

      case 'mark_attendance': {
        const { data, error } = await supabase
          .from('attendance')
          .insert({
            student_id: args.student_id,
            course_id: args.course_id,
            date: args.date,
            status: args.status,
            marked_at: new Date().toISOString(),
          })
          .select();

        if (error) throw error;

        return {
          content: [
            {
              type: 'text',
              text: `Attendance marked successfully: ${args.status}`,
            },
          ],
        };
      }

      case 'search_courses': {
        let query = supabase.from('courses').select('*').eq('is_active', true);

        if (args.query) {
          query = query.or(`title.ilike.%${args.query}%,description.ilike.%${args.query}%`);
        }

        if (args.category) {
          query = query.eq('category', args.category);
        }

        if (args.max_price) {
          query = query.lte('price', args.max_price);
        }

        const { data, error } = await query;

        if (error) throw error;

        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(data, null, 2),
            },
          ],
        };
      }

      case 'enroll_student': {
        // Check wallet balance if using wallet
        if (args.use_wallet) {
          const { data: student } = await supabase
            .from('students')
            .select('wallet_balance')
            .eq('id', args.student_id)
            .single();

          if (student.wallet_balance < args.amount) {
            throw new Error('Insufficient wallet balance');
          }

          // Deduct from wallet
          await supabase
            .from('earnings')
            .insert({
              student_id: args.student_id,
              amount: -args.amount,
              type: 'bonus',
              description: 'Course enrollment payment',
            });
        }

        // Create enrollment
        const { data, error } = await supabase
          .from('enrollments')
          .insert({
            student_id: args.student_id,
            course_id: args.course_id,
            amount_paid: args.amount,
            payment_status: args.use_wallet ? 'completed' : 'pending',
          })
          .select();

        if (error) throw error;

        return {
          content: [
            {
              type: 'text',
              text: `Student enrolled successfully! Enrollment ID: ${data[0].id}`,
            },
          ],
        };
      }

      case 'get_referral_stats': {
        const { data: referrals, error } = await supabase
          .from('referrals')
          .select('*')
          .eq('referrer_id', args.student_id);

        if (error) throw error;

        const stats = {
          total_referrals: referrals.length,
          completed: referrals.filter((r) => r.status === 'completed').length,
          pending: referrals.filter((r) => r.status === 'pending').length,
          total_earned: referrals.reduce((sum, r) => sum + (r.reward_amount || 0), 0),
        };

        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(stats, null, 2),
            },
          ],
        };
      }

      case 'create_lead': {
        const { data, error } = await supabase
          .from('leads')
          .insert({
            full_name: args.full_name,
            phone: args.phone,
            email: args.email,
            source: args.source,
            interest: args.interest || [],
            status: 'new',
          })
          .select();

        if (error) throw error;

        return {
          content: [
            {
              type: 'text',
              text: `Lead created successfully! ID: ${data[0].id}`,
            },
          ],
        };
      }

      case 'get_analytics': {
        let result;

        switch (args.metric) {
          case 'enrollments': {
            const { count } = await supabase
              .from('enrollments')
              .select('*', { count: 'exact', head: true });
            result = { total_enrollments: count };
            break;
          }

          case 'revenue': {
            const { data } = await supabase
              .from('enrollments')
              .select('amount_paid')
              .eq('payment_status', 'completed');
            
            const total = data.reduce((sum, e) => sum + (e.amount_paid || 0), 0);
            result = { total_revenue: total };
            break;
          }

          case 'students': {
            const { count } = await supabase
              .from('students')
              .select('*', { count: 'exact', head: true });
            result = { total_students: count };
            break;
          }

          case 'courses': {
            const { count } = await supabase
              .from('courses')
              .select('*', { count: 'exact', head: true })
              .eq('is_active', true);
            result = { active_courses: count };
            break;
          }

          case 'earnings_paid': {
            const { data } = await supabase
              .from('earnings')
              .select('amount')
              .gt('amount', 0);
            
            const total = data.reduce((sum, e) => sum + e.amount, 0);
            result = { total_earnings_paid: total };
            break;
          }
        }

        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'send_notification': {
        const { data, error } = await supabase
          .from('notifications')
          .insert({
            user_id: args.user_id,
            title: args.title,
            message: args.message,
            type: args.type,
          })
          .select();

        if (error) throw error;

        return {
          content: [
            {
              type: 'text',
              text: 'Notification sent successfully!',
            },
          ],
        };
      }

      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  } catch (error) {
    return {
      content: [
        {
          type: 'text',
          text: `Error: ${error.message}`,
        },
      ],
      isError: true,
    };
  }
});

// Start the server
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('JeetMantra MCP Server running on stdio');
}

main().catch((error) => {
  console.error('Server error:', error);
  process.exit(1);
});
