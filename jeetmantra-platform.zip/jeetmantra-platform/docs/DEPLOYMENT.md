# JeetMantra Platform - Deployment Guide

## 🚀 Quick Start Deployment

### Prerequisites
- Node.js 18+ installed
- Supabase account
- n8n instance (cloud or self-hosted)
- Git installed
- (Optional) Netlify/Vercel account
- (Optional) Railway/Fly.io account

## 📋 Step-by-Step Deployment

### 1. Supabase Setup (15 minutes)

#### Create Project
1. Go to [supabase.com](https://supabase.com)
2. Click "New Project"
3. Fill in details:
   - **Name**: JeetMantra
   - **Database Password**: (save this!)
   - **Region**: Mumbai (ap-south-1)

#### Run Migrations
1. Navigate to SQL Editor in Supabase Dashboard
2. Copy content from `supabase/migrations/001_initial_schema.sql`
3. Execute the SQL
4. Verify tables created in Table Editor

#### Get API Credentials
1. Go to Project Settings → API
2. Copy:
   - **Project URL**
   - **anon/public key**
   - **service_role key** (keep secret!)

### 2. Frontend Deployment (10 minutes)

#### Option A: Netlify

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login
netlify login

# Deploy
cd frontend
netlify deploy --prod

# Answer prompts:
# - Build directory: . (current directory)
# - Publish directory: . (current directory)
```

#### Option B: Vercel

```bash
# Install Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy
cd frontend
vercel --prod
```

#### Option C: Simple HTTP Server (Development)

```bash
cd frontend
python -m http.server 8000
# or
npx http-server -p 8000
```

### 3. Configure Frontend

Edit `frontend/js/supabase-client.js`:

```javascript
const SUPABASE_URL = 'https://your-project.supabase.co';
const SUPABASE_ANON_KEY = 'your-anon-key-here';
```

### 4. MCP Server Deployment (20 minutes)

#### Prepare Server

```bash
cd mcp-server

# Create .env file
cat > .env << EOF
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=your-service-role-key
EOF

# Install dependencies
npm install
```

#### Option A: Railway Deployment

1. Go to [railway.app](https://railway.app)
2. Create new project
3. Connect GitHub repository
4. Add environment variables
5. Deploy

```bash
# Or use Railway CLI
npm install -g @railway/cli
railway login
railway up
```

#### Option B: Fly.io Deployment

```bash
# Install Fly CLI
curl -L https://fly.io/install.sh | sh

# Login
fly auth login

# Initialize
fly launch

# Deploy
fly deploy
```

#### Option C: Run Locally

```bash
npm start
# Server runs on http://localhost:3001
```

### 5. n8n Setup (30 minutes)

#### Option A: n8n Cloud

1. Go to [n8n.cloud](https://n8n.cloud)
2. Create account
3. Create new workflow
4. Import workflow JSON files from `n8n-workflows/`

#### Option B: Self-hosted n8n

```bash
# Using Docker
docker run -it --rm \
  --name n8n \
  -p 5678:5678 \
  -v ~/.n8n:/home/node/.n8n \
  n8nio/n8n

# Using npm
npm install -g n8n
n8n start
```

#### Import Workflows

1. Open n8n (http://localhost:5678 or your cloud URL)
2. Go to Workflows
3. Click "Import from File"
4. Upload `whatsapp-bot.json`
5. Repeat for other workflows

#### Configure Credentials

1. **Supabase**:
   - URL: Your Supabase URL
   - Service Key: Your service role key

2. **Twilio** (for WhatsApp):
   - Account SID: From Twilio dashboard
   - Auth Token: From Twilio dashboard
   - WhatsApp Number: Your Twilio WhatsApp number

3. **Anthropic** (for AI):
   - API Key: From Anthropic dashboard

### 6. WhatsApp Bot Configuration (15 minutes)

#### Setup Twilio

1. Go to [twilio.com](https://www.twilio.com)
2. Create account (or login)
3. Go to Messaging → Try it out → Send a WhatsApp message
4. Get WhatsApp Sandbox number
5. Configure webhook:
   - URL: `https://your-n8n-instance.com/webhook/whatsapp-webhook`
   - Method: POST

#### Test WhatsApp Bot

1. Send a message to Twilio WhatsApp number
2. Test: "I want to know about courses"
3. Should receive AI-powered response

### 7. Environment Variables

Create `.env` file in root:

```bash
# Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_KEY=your-service-key

# n8n
N8N_HOST=https://your-n8n.app
N8N_API_KEY=your-n8n-api-key

# Twilio
TWILIO_ACCOUNT_SID=your-sid
TWILIO_AUTH_TOKEN=your-token
TWILIO_WHATSAPP_NUMBER=whatsapp:+14155238886

# Anthropic
ANTHROPIC_API_KEY=your-anthropic-key

# App
APP_URL=https://jeetmantra.com
```

## 🔐 Security Checklist

- [ ] Changed all default passwords
- [ ] Enabled RLS on all Supabase tables
- [ ] Service role key is secret (not in frontend)
- [ ] n8n webhooks have authentication
- [ ] SSL certificates enabled
- [ ] API rate limiting configured
- [ ] CORS properly configured
- [ ] Environment variables secured

## 🧪 Testing

### Frontend
```bash
# Open in browser
http://localhost:8000

# Test features:
- [ ] Course listing loads
- [ ] Login/Signup works
- [ ] Demo booking works
- [ ] Contact form works
```

### MCP Server
```bash
# Test using MCP Inspector
npx @modelcontextprotocol/inspector

# Connect to: http://localhost:3001
# Test tools:
- [ ] get_student_profile
- [ ] search_courses
- [ ] create_lead
```

### n8n Workflows
```bash
# In n8n UI:
- [ ] Manual trigger works
- [ ] Webhook responds
- [ ] Supabase connection works
- [ ] AI response generates
```

## 🐛 Troubleshooting

### Supabase Connection Failed
```
Error: Invalid API key
Solution: Check SUPABASE_URL and SUPABASE_ANON_KEY
```

### CORS Error in Frontend
```
Solution: 
1. Check Supabase Dashboard → Authentication → URL Configuration
2. Add your domain to allowed URLs
```

### n8n Webhook Not Responding
```
Solution:
1. Check n8n is running
2. Verify webhook path matches
3. Check n8n logs for errors
```

### MCP Server Won't Start
```
Solution:
1. Check Node.js version (must be 18+)
2. Verify all dependencies installed
3. Check environment variables
```

## 📊 Monitoring

### Supabase Dashboard
- Database usage
- API requests
- Storage usage
- Auth activity

### n8n Dashboard
- Workflow executions
- Error logs
- Execution time

### Application Logs
```bash
# MCP Server logs
npm run mcp

# n8n logs
docker logs n8n

# Frontend (browser console)
F12 → Console tab
```

## 🔄 Updates & Maintenance

### Database Migrations
```bash
# Create new migration
# Edit: supabase/migrations/002_new_feature.sql

# Run migration
# Via Supabase Dashboard SQL Editor
```

### Frontend Updates
```bash
# Make changes
git commit -am "Update frontend"

# Deploy
netlify deploy --prod
# or
vercel --prod
```

### MCP Server Updates
```bash
# Make changes
git commit -am "Update MCP server"

# Deploy
railway up
# or
fly deploy
```

## 📈 Scaling

### When to Scale

**Database**:
- More than 100,000 students
- More than 10,000 daily active users

**MCP Server**:
- Response time > 2 seconds
- CPU usage > 80%

**n8n**:
- Workflow executions > 1000/hour
- Execution queue backlog

### How to Scale

**Supabase**:
- Upgrade to Pro plan
- Enable connection pooling
- Add read replicas

**MCP Server**:
- Horizontal scaling (multiple instances)
- Load balancer
- Redis cache

**n8n**:
- Separate queue mode
- Multiple worker instances

## 🎯 Production Checklist

- [ ] All services deployed
- [ ] Environment variables configured
- [ ] SSL certificates installed
- [ ] Database backups enabled
- [ ] Monitoring set up
- [ ] Error tracking configured
- [ ] Load testing completed
- [ ] Security audit done
- [ ] Documentation updated
- [ ] Team trained

## 📞 Support

For issues or questions:
- Email: support@jeetmantra.com
- WhatsApp: +91 9876543210
- Documentation: https://docs.jeetmantra.com

---

**Estimated Total Deployment Time**: 1.5 - 2 hours  
**Difficulty**: Intermediate  
**Cost**: $0 (free tier) to $50/month (production)
