# JeetMantra Platform Architecture

## 🏗️ System Overview

JeetMantra is a modern education platform built with a serverless architecture, combining:
- **Frontend**: Vanilla JavaScript (lightweight, fast)
- **Backend**: Supabase (PostgreSQL, Auth, Storage, Realtime)
- **Automation**: n8n (Workflows, WhatsApp bot, CRM)
- **AI**: MCP Server + Claude (Intelligent features)

## 📊 Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                        USER INTERFACES                       │
├─────────────────────────────────────────────────────────────┤
│  Web Browser  │  Mobile App   │  WhatsApp    │  Admin Panel │
└────────┬──────────────┬────────────┬───────────────┬────────┘
         │              │            │               │
         ▼              ▼            ▼               ▼
┌─────────────────────────────────────────────────────────────┐
│                    APPLICATION LAYER                         │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   Frontend   │    │     n8n      │    │  MCP Server  │  │
│  │  (HTML/CSS/  │◄───┤  Workflows   │◄───┤   (AI Tools) │  │
│  │     JS)      │    │  Automation  │    │              │  │
│  └──────┬───────┘    └──────┬───────┘    └──────┬───────┘  │
│         │                   │                    │           │
│         └───────────────────┼────────────────────┘           │
│                             │                                │
└─────────────────────────────┼────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                       SUPABASE LAYER                         │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐            │
│  │ PostgreSQL │  │    Auth    │  │  Storage   │            │
│  │  Database  │  │  (JWT)     │  │  (S3)      │            │
│  └────────────┘  └────────────┘  └────────────┘            │
│                                                               │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐            │
│  │  Realtime  │  │  Functions │  │    RLS     │            │
│  │ (WebSocket)│  │  (Edge)    │  │ (Security) │            │
│  └────────────┘  └────────────┘  └────────────┘            │
│                                                               │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   EXTERNAL INTEGRATIONS                      │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  Claude AI  │  Twilio    │  Razorpay  │  Email    │  SMS    │
│  (MCP)      │  (WhatsApp)│  (Payment) │  Service  │  Service│
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## 🔐 Security Architecture

### Row Level Security (RLS)
- Students can only access their own data
- Teachers can only manage their courses
- Partners can only see their bookings
- Admins have full access

### Authentication Flow
```
User → Sign Up/Login → Supabase Auth → JWT Token → RLS Policies
```

### API Security
- Supabase Anon Key: Client-side operations
- Service Role Key: MCP server operations
- n8n Webhooks: Signature verification

## 💾 Database Design

### Core Tables
1. **profiles** - Base user information
2. **students** - Student-specific data + wallet
3. **teachers** - Teacher profiles + earnings
4. **partners** - Partner organizations
5. **courses** - Course catalog
6. **enrollments** - Student-course mapping
7. **earnings** - All earning transactions
8. **referrals** - Referral tracking
9. **attendance** - Attendance records
10. **leads** - CRM lead management

### Relationships
```sql
profiles (1) → (1) students
profiles (1) → (1) teachers
profiles (1) → (1) partners

courses (1) → (many) enrollments → (1) students
courses (1) → (many) content
courses (1) → (1) teachers

students (1) → (many) earnings
students (1) → (many) referrals
```

## 🤖 AI Integration (MCP)

### MCP Server Capabilities
1. **Student Management**
   - Profile queries
   - Enrollment automation
   - Performance tracking

2. **Course Operations**
   - Search and filter
   - Recommendations
   - Content management

3. **Analytics**
   - Revenue tracking
   - Enrollment stats
   - Performance metrics

4. **Notifications**
   - Attendance reminders
   - Payment alerts
   - Earning notifications

### Claude AI Usage
```javascript
// Example: AI-powered course recommendation
const response = await fetch('https://api.anthropic.com/v1/messages', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    model: 'claude-sonnet-4-20250514',
    messages: [
      {
        role: 'user',
        content: 'Recommend courses for JEE preparation'
      }
    ],
    mcp_servers: [
      {
        type: 'url',
        url: 'http://localhost:3001',
        name: 'jeetmantra-mcp'
      }
    ]
  })
});
```

## 🔄 n8n Workflows

### 1. WhatsApp Bot Workflow
```
Webhook → Parse Message → AI Response → Send Reply
                ↓
           Create Lead (if demo request)
                ↓
           Update Supabase
```

### 2. Lead Automation
```
Website Form → Create Lead → Assign to Staff → Send Welcome Message
                                    ↓
                            Schedule Follow-up (24h, 48h, 7d)
```

### 3. Attendance System
```
Schedule Trigger (Daily 8 AM) → Get Today's Classes
                                        ↓
                               Generate OTP Codes
                                        ↓
                               Send to WhatsApp
                                        ↓
                          Update Attendance Table
```

### 4. Payment Reminders
```
Schedule Trigger (Weekly) → Find Pending Payments
                                    ↓
                            Send Reminder (Email + WhatsApp)
                                    ↓
                            Log Activity in CRM
```

## 📱 Frontend Architecture

### Structure
```
frontend/
├── index.html          # Main page
├── css/
│   └── styles.css     # Design system
├── js/
│   ├── app.js         # Main logic
│   ├── supabase-client.js
│   └── api/
│       ├── auth.js
│       ├── courses.js
│       ├── earnings.js
│       └── dashboard.js
└── assets/
    └── images/
```

### State Management
- No framework (vanilla JS)
- Local state in memory
- Supabase Realtime for live updates
- localStorage for client-side cache

### API Communication
```javascript
// All API calls go through Supabase
const { data, error } = await supabase
  .from('courses')
  .select('*')
  .eq('is_active', true);
```

## 🚀 Deployment Strategy

### Frontend
- **Platform**: Netlify / Vercel
- **CDN**: Automatic via platform
- **SSL**: Automatic
- **Deploy**: Git push to main branch

### Supabase
- **Platform**: Supabase Cloud
- **Region**: Mumbai (ap-south-1)
- **Backup**: Automatic daily
- **Scaling**: Automatic

### MCP Server
- **Platform**: Railway / Fly.io
- **Container**: Node.js 18
- **Environment**: Production
- **Scaling**: Manual

### n8n
- **Platform**: n8n Cloud / Self-hosted
- **Workflows**: Import via JSON
- **Credentials**: Encrypted
- **Execution**: Event-driven

## 📊 Data Flow Examples

### Student Enrollment Flow
```
1. Student clicks "Enroll" → 
2. Check authentication → 
3. Redirect to payment → 
4. Payment success → 
5. Create enrollment record → 
6. Update course student count → 
7. Send confirmation (email + WhatsApp) → 
8. Grant access to content
```

### Earning Flow
```
1. Referral completes payment → 
2. Trigger in Supabase → 
3. Create earning record → 
4. Update wallet balance (via trigger) → 
5. Send notification → 
6. Update leaderboard
```

### Attendance Flow
```
1. n8n generates OTP (daily) → 
2. Sends to student WhatsApp → 
3. Student enters OTP in app → 
4. Verify and mark attendance → 
5. Update database → 
6. Send confirmation to parent
```

## 🔧 Environment Setup

### Development
```bash
# 1. Clone repository
git clone https://github.com/jeetmantra/platform.git

# 2. Setup environment
cp .env.example .env
# Edit .env with your credentials

# 3. Install dependencies
npm install

# 4. Run migrations
npm run migrate

# 5. Start MCP server
npm run mcp:dev

# 6. Start frontend
npm run dev
```

### Production
```bash
# 1. Build (if needed)
npm run build

# 2. Deploy frontend
netlify deploy --prod

# 3. Deploy MCP server
railway up

# 4. Import n8n workflows
# Via n8n UI: Import JSON files
```

## 📈 Scalability Considerations

### Database
- Indexes on frequently queried columns
- Partitioning for large tables (attendance, earnings)
- Read replicas for analytics

### Frontend
- CDN for static assets
- Lazy loading for images
- Code splitting for routes

### MCP Server
- Horizontal scaling with load balancer
- Redis for caching
- Rate limiting

### n8n
- Queue system for heavy workflows
- Separate execution instances
- Monitoring and alerting

## 🔍 Monitoring & Analytics

### Application Monitoring
- Supabase Dashboard
- n8n execution logs
- MCP server logs

### Business Metrics
- Daily active users
- Enrollment rate
- Earnings distribution
- Course completion rate

### Error Tracking
- Supabase Error Logs
- n8n Error Workflows
- Frontend error boundary

## 🛡️ Backup & Recovery

### Database
- Automatic daily backups (Supabase)
- Point-in-time recovery
- Export scripts for critical data

### Workflows
- n8n workflow exports (JSON)
- Version control in Git

### Files
- Supabase Storage automatic backup
- Periodic manual backup to S3

## 📝 API Documentation

See `/docs/API.md` for detailed API documentation.

### Key Endpoints
- `POST /auth/signup` - User registration
- `POST /auth/login` - User login
- `GET /courses` - List courses
- `POST /enroll` - Enroll in course
- `GET /earnings/:student_id` - Get earnings

### MCP Tools
- `get_student_profile`
- `get_student_enrollments`
- `search_courses`
- `enroll_student`
- `mark_attendance`
- `create_lead`
- `get_analytics`

---

**Version**: 1.0.0  
**Last Updated**: 2024  
**Maintained by**: JeetMantra Development Team
