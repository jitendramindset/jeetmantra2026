# JeetMantra - Modern Gurukul Platform

## 🚀 Overview

JeetMantra is a next-generation education ecosystem that combines academic coaching with skills, AI, sports, and earning opportunities. This platform integrates:

- **Supabase** - Backend database, authentication, storage
- **n8n** - Workflow automation for WhatsApp AI, CRM, notifications
- **MCP (Model Context Protocol)** - AI integration for intelligent features
- **Vanilla JavaScript** - Fast, lightweight frontend

## 📁 Project Structure

```
jeetmantra-platform/
├── frontend/
│   ├── index.html
│   ├── css/
│   │   └── styles.css
│   ├── js/
│   │   ├── app.js
│   │   ├── supabase-client.js
│   │   ├── api/
│   │   │   ├── auth.js
│   │   │   ├── courses.js
│   │   │   ├── earnings.js
│   │   │   └── dashboard.js
│   │   └── components/
│   │       ├── header.js
│   │       ├── course-card.js
│   │       └── earning-widget.js
│   └── assets/
│       └── images/
├── mcp-server/
│   ├── index.js
│   ├── package.json
│   └── tools/
│       ├── student-tools.js
│       ├── teacher-tools.js
│       └── admin-tools.js
├── n8n-workflows/
│   ├── whatsapp-bot.json
│   ├── lead-automation.json
│   └── attendance-reminder.json
├── supabase/
│   ├── migrations/
│   │   └── 001_initial_schema.sql
│   └── functions/
│       ├── calculate-earnings/
│       └── send-notification/
└── docs/
    ├── ARCHITECTURE.md
    └── DEPLOYMENT.md
```

## 🎨 Design System

**Colors:**
- Primary: #f97316 (Saffron Orange)
- Secondary: #0f172a (Deep Navy Blue)
- Background: #ffffff
- Gray: #f4f6f8

**Typography:**
- Headings: Bold sans-serif
- Body: Inter/Arial

## 🔧 Tech Stack

- **Frontend**: Vanilla JavaScript, HTML5, CSS3
- **Backend**: Supabase (PostgreSQL)
- **Automation**: n8n
- **AI Integration**: MCP Server + Claude
- **Authentication**: Supabase Auth
- **Storage**: Supabase Storage
- **Real-time**: Supabase Realtime

## 📦 Installation

### Prerequisites
- Node.js 18+
- Supabase account
- n8n instance (cloud or self-hosted)

### Setup Steps

1. **Clone and Install**
```bash
npm install
```

2. **Configure Supabase**
```bash
# Copy environment template
cp .env.example .env

# Add your Supabase credentials
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_KEY=your_service_key
```

3. **Run Database Migrations**
```bash
npm run migrate
```

4. **Start MCP Server**
```bash
cd mcp-server
npm install
npm start
```

5. **Import n8n Workflows**
- Open n8n
- Import workflows from `n8n-workflows/`
- Configure credentials

6. **Launch Frontend**
```bash
# Simple HTTP server
npm run dev
# or
python -m http.server 8000
```

## 🗄️ Database Schema

### Core Tables
- `students` - Student profiles
- `teachers` - Teacher profiles
- `courses` - Course catalog
- `enrollments` - Student-course mapping
- `attendance` - Attendance records
- `earnings` - Earning transactions
- `referrals` - Referral tracking
- `activities` - Skills/sports activities
- `bookings` - Class bookings

## 🤖 AI Features (MCP)

The MCP server provides AI-powered tools:

1. **Student Management**
   - Enrollment automation
   - Performance tracking
   - Earning calculation

2. **Teacher Tools**
   - Class scheduling
   - Content management
   - Earnings dashboard

3. **Admin Tools**
   - Lead management
   - Analytics
   - Bulk operations

## 🔄 n8n Workflows

1. **WhatsApp Bot**
   - Course inquiries
   - Demo booking
   - Payment reminders

2. **Lead Automation**
   - Lead capture from website
   - Follow-up sequences
   - Conversion tracking

3. **Attendance System**
   - QR/OTP generation
   - Attendance marking
   - Parent notifications

## 🚀 Deployment

### Frontend (Netlify/Vercel)
```bash
npm run build
# Deploy dist/ folder
```

### MCP Server (Railway/Fly.io)
```bash
cd mcp-server
npm run deploy
```

### Supabase
- Already hosted
- Manage via dashboard

### n8n
- Use n8n Cloud or self-host

## 📚 Documentation

- [Architecture Overview](./docs/ARCHITECTURE.md)
- [API Documentation](./docs/API.md)
- [User Guide](./docs/USER_GUIDE.md)

## 🎯 Key Features

✅ Course marketplace
✅ Student earning system
✅ Attendance tracking (QR/OTP)
✅ WhatsApp AI assistant
✅ Referral program
✅ Teacher portal
✅ Partner dashboard
✅ Real-time notifications
✅ Content library
✅ AI-powered automation

## 📧 Contact

**JeetMantra**
- Location: Galaxia Mall, Ranchi
- Email: info@jeetmantra.com
- Website: jeetmantra.com

## 📄 License

Proprietary - All rights reserved
